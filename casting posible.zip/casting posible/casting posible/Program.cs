﻿// See https://aka.ms/new-console-template for more information 
/*
 * hacer un programa que lea nombre de un producto, cantidad y presio respectivamente validados
 * y almacenarlos en un archivo, este proceso se realizara hasta que el usuario lo desee
 * al finalizar se agregara al archivo el total de productos y el total de los precios, considerando
 * la cantidad de productos 
 * 
 *string num;
int n;
Console.WriteLine("Escribe un numero:");
num = Console.ReadLine();
if(Int32.TryParse(num,out n)) // valida si ingresa numeros
{
    Console.WriteLine("Son puros numeros enteros");
}
else
{
    Console.WriteLine("No son puros numeros enteros");
}
 * */

string dato1 ="",dato2="", cantidad="",precio="",pregunta="",nomarc="Compras.txt";
int precio1 = 0,cont=0,cantidad1=0,aux=0,pago=0,si=0;

StreamWriter archivo;

while (true)
{
    while (true)
    {

        Console.Write("Ingresa la cantidad que desea  ");
        cantidad = Console.ReadLine();
        if (Int32.TryParse(cantidad, out cantidad1))
        {
            cantidad1 = Convert.ToInt32(cantidad);
            cont = cont + cantidad1;
            break;
        }
        else
        {
            Console.WriteLine("Ingrese solo numeros");
        }
    }

    while (true)
    {
        Console.Write("Ingrese el precio: ");
        precio = Console.ReadLine();
        if (Int32.TryParse(precio, out precio1))
        {
            precio1 = Convert.ToInt32(precio);
            pago = precio1 * cantidad1;
            aux = aux + pago;
            break;
        }
        else
        {
            Console.WriteLine("Solo numeros");
        }
    }

    Console.WriteLine("cantidad de productos es de:{0} ", cont);
    Console.WriteLine("La cantidad a pagar es de ${0}", aux);




    Console.Write("Quieres seguir? si/no: ");
    pregunta = Console.ReadLine();
    if (pregunta.Equals("si") || pregunta.Equals("Si"))
    {

    }
    else
    {
        dato1 = "La cantidad de productos es de: " + cont.ToString() +
            " y el precio final es de: " + aux.ToString();

        Console.WriteLine(dato1);


        Console.Write("Gracias por usarnos, feliz dia");
        break;
    }
}



