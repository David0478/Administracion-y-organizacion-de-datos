﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
//hacer un programa que lea nombre,cantidad y precio de 5 productos,el programa
//mostrara al finalizar el porcentaje de iva y el total a pagar


double p1, p2, p3, p4, p5,iva,pagoni,c1,c2,c3,c4,c5,pagoiv;
String pr1, pr2, pr3, pr4, pr5;

Console.Write("Ingresa el nombre del producto: ");
pr1 = Console.ReadLine();
Console.Write("Ingrese la cantidad que quiere: ");
c1 = Convert.ToDouble(Console.ReadLine());
Console.Write("Ingresa el precio del producto $ ");
p1 = Convert.ToDouble(Console.ReadLine());
Console.Write("Ingresa el nombre del producto: ");
pr2 = Console.ReadLine();
Console.Write("Ingrese la cantidad que quiere: ");
c2 = Convert.ToDouble(Console.ReadLine());
Console.Write("Ingresa el precio del producto $ ");
p2 = Convert.ToDouble(Console.ReadLine());
Console.Write("Ingresa el nombre del producto: ");
pr3 = Console.ReadLine();
Console.Write("Ingrese la cantidad que quiere: ");
c3 = Convert.ToDouble(Console.ReadLine());
Console.Write("Ingresa el precio del producto $ ");
p3 = Convert.ToDouble(Console.ReadLine());
Console.Write("Ingresa el nombre del producto: ");
pr4 = Console.ReadLine();
Console.Write("Ingrese la cantidad que quiere: ");
c4 = Convert.ToDouble(Console.ReadLine());
Console.Write("Ingresa el precio del producto $ ");
p4 = Convert.ToDouble(Console.ReadLine());
Console.Write("Ingresa el nombre del producto: ");
pr5 = Console.ReadLine();
Console.Write("Ingrese la cantidad que quiere: ");
c5 = Convert.ToDouble(Console.ReadLine());
Console.Write("Ingresa el precio del producto $ ");
p5 = Convert.ToDouble(Console.ReadLine());
pagoni = (p1 * c1) + (p2 * c2) + (p3 * c3) + (p4 * c4) + (p5 * c5);
pagoiv = pagoni * .16;
Console.Write("El iva es de: {0}, por lo que el total a pagar es de:$ {1}", pagoiv, pagoni+pagoiv);

/*
double precio, aux=0, iva; ;
String producto;

for(int i = 0; i < 4; i++)
{
    Console.Write("Ingresa el nombre del producto: ");
    producto = Console.ReadLine();

    Console.Write("Ingresa el precio de los productos: $");
    precio = Convert.ToDouble(Console.ReadLine());
    aux = aux + precio;

}

iva = aux * 0.16;
Console.Write("El iva es de: ${0}, por lo que el precio final es de: ${1}",iva,aux-iva);
*/