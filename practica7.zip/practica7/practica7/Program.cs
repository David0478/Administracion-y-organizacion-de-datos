﻿StreamWriter fichero; // es la accion para escribirlo, como su nombre dice, es un objeto
string linea,res="s"; // son lineas xd
fichero = File.AppendText("prueba.txt");//es como arreglo, appen es agregar, por lo que es a gusto el tamaño
//fichero.WriteLine("añadimos texto al fichero, sino existe se crea");escribe el
while (res == "s")
{
    Console.WriteLine("Escribe una linea");
    linea = Console.ReadLine();
    fichero.WriteLine(linea);
}
fichero.Close();//cierra el archivo

StreamReader miLectura = File.OpenText("prueba.txt");//aqui abrimos el archivo
try
{
    do
    {
        linea = miLectura.ReadLine();
        Console.WriteLine(linea);
    } while (linea != null);//decimos que si no esta vacio haga el ciclo

    miLectura.Close();
}
catch (Exception msg) // Si no se puede leer mostramos el error
{
    Console.WriteLine("No se encuentra el archivo " + msg);
}