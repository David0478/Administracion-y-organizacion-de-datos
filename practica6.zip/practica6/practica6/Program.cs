﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
//hacer un programa que lea nombre del alumno, de la materia y 4 calificaciones, el programa calculara el promedio
//de la materia y la almacenara en una lista. Esta accion se repetira hasta que el usuario lo desee.
//al finalizar el programa mostrara el promedio de todas las materias

List<List<string>> alumnados = new List<List<string>>();
string nombre,materia;
double calificacion,prom;
bool estado = true;
int pregunta;

while (estado == true)
{
    try
    {
        double aux = 0;
        Console.Write("Ingresa tu nombre alumno: ");
        nombre = Console.ReadLine();
        Console.Write("Ingresa la materia: ");
        materia = Console.ReadLine();
        for (int i = 0; i < 4; i++)
        {
            Console.Write("Ingresa las calificaciones de la materia: ");
            calificacion = Convert.ToDouble(Console.ReadLine());
            aux = aux + calificacion;
        }
        prom = (aux) / 4;
        List<string> info = new List<string>();
        info.Add(nombre);
        info.Add(materia);
        info.Add(prom.ToString());
        alumnados.Add(info);
        Console.Write("¿Quieres seguir? 1 si/ 2 no: ");
        pregunta = Convert.ToInt32(Console.ReadLine());
        if (pregunta != 1)
        {
            estado = false;
        }
    }
    catch (Exception)
    {
        throw;
    }
}
foreach(var i in alumnados)
{
    Console.WriteLine(String.Join(",", i));
}


