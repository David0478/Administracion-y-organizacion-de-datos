﻿// See https://aka.ms/new-console-template for more information
/*hacer un programa que muestre este menu
//introducir un numero decimal
//un numero binario
//un numero hexadecimal
//dependiendo de la opcion es el dato que se va a solicitar para realizar las siguientes operaciones
1.- Si es decimal, se elevala al cuadrado y su resultado se mostrara en binario y hexadecimal
2.- Si es binario se sumara al resultado del cuadrado del mismo y se mostrara en decimal y hexadecimal
3.- Si el valor es hexadecimal se mostrara su tabla de multiplicar, esta tabla sera en hexadecimal
int dato = 300;
Console.Write("El numero en binario es: ");
Console.WriteLine(Convert.ToString(dato,2)); // (n,2) el 2 significa que sera en binario 
Console.Write("El numero en hexadecimal es: ");
Console.WriteLine(Convert.ToString(dato, 16)); //(n,16) el 16 significa que sera hexadecimal

Console.WriteLine("Escribe un numero dato en binario: ");
Console.WriteLine("En decimal es: {0}", Convert.ToInt32(Console.ReadLine(), 2));
Console.WriteLine("Dime un dato en hexadecimal: ");
Console.WriteLine("En decimal es: {0}", Convert.ToInt32(Console.ReadLine(), 16));
*/


StreamWriter archivo;



int opcion,numero,resultado=0,resultado2=0;
string operacion = "Operaciones con archivos.txt",dato1="",dato2="",dato3="";
Console.WriteLine("Elige una opcion del menu \n" +
    "1.- Introducir un numero decimal\n" +
    "2.- Introducir un numero binario\n" +
    "3.- Introducir un numero Hexadecimal");

Console.Write("Ingresa la opcion deseada: ");
opcion = Convert.ToInt32(Console.ReadLine());

try
{

    archivo = File.AppendText(operacion);
    switch (opcion)
    {
        case 1:
            Console.Write("Ingresa el numero: ");
            numero = Convert.ToInt32(Console.ReadLine());
            resultado = numero * numero;
            Console.WriteLine("El resultado del cuadrado del numero ingresado es :{0} en binario, y en hexadecimal es: {1}"
                , Convert.ToString(resultado, 2), Convert.ToString(resultado, 16));
            dato1="El resultado del cuadrado del numero ingresado es :"+ Convert.ToString(resultado, 2)+" en binario, y en hexadecimal es: " +
                Convert.ToString(resultado, 16);
            archivo.WriteLine(dato1);
            archivo.Close();
            break;


        case 2:
            Console.Write("Ingresa el numero en binario: ");
            numero = Convert.ToInt32(Console.ReadLine(), 2);
            Console.WriteLine(numero);
            resultado = numero * numero;
            resultado2 = resultado + numero;
            Console.Write("El resultado de el cuadrado y sumado a el mismo es de: {0}, y su valor en hexadecimal es de: {1}", resultado2, Convert.ToString(resultado2, 16));
            dato2 = "El resultado de el cuadrado y sumado a el mismo es de: " + resultado2.ToString() + " y su valor en hexadecimal es de: " + Convert.ToString(resultado2, 16);
            archivo.WriteLine(dato2);
            archivo.Close();
            break;


        case 3:

            Console.Write("Ingresa el numero en Hexadecimal: ");
            numero = Convert.ToInt32(Console.ReadLine(), 16);

            for (int i = 0; i < 11; i++)
            {
                Console.WriteLine("{0} x {1}= {2}", Convert.ToString(numero, 16), i, (Convert.ToString((numero * i), 16)));
                dato3= Convert.ToString(numero, 16)+ i+ (Convert.ToString((numero * i)+ 16));
                archivo.WriteLine(dato3);
            }
            archivo.Close();
            break;

        default:
            break;
    }
}
catch (Exception msg)
{
    Console.WriteLine("No se encuentra el archivo " + msg);
}
