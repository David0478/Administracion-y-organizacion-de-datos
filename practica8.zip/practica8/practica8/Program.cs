﻿// See https://aka.ms/new-console-template for more information
StreamWriter fichero;
int a=0,resultado=0;
 string nombre = "tabla.txt";
string dato = "";

try
{
    fichero = File.AppendText(nombre); //crea el archivo o reutiliza
    /*StreamReader miLectura = File.OpenText(nombre);//abrimos el archivo
         Console.WriteLine(miLectura);*/
    Console.Write("Escribe un numero : ");
    a = Convert.ToInt32(Console.ReadLine());

    for (int i = 1; i <= 10; i++)
    {
        resultado = a * i;
        dato = a.ToString() + " * " + i.ToString() + " = " + resultado.ToString();
        Console.WriteLine(dato);
        fichero.WriteLine(dato);
    }

    fichero.Close();

}
catch (Exception msg)
{
    Console.WriteLine("No se encuentra el archivo "+msg);
}

