﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");  ESTRUCTURAS
/*
 Hacer un programa que lea 3 numeros, si los numeros  son iguales se calculara el promedio, de lo contrario
 se sumaran los numeros que son pares o impares entre ellos, mostrara el mayor y menor de ellos

int a;
Console.Write("Escribe un numero: ");
a = Convert.ToInt32(Console.ReadLine());
if (a > 10)
{
    Console.WriteLine("El valor de la multiplicacion es: {0}",a*a);
}
else if(a<10)
{
    Console.WriteLine(a / a);
}
else if(a==10)
{
    Console.Write("Hola");
}

switch(a)
{
    case 1:
        break;
    case 2:
        break;
    default:
        break;
}

 */

//break,continue,goto

int a, b, c;
Console.WriteLine("Ingresa 3 numeros");
a = Convert.ToInt32(Console.ReadLine());
b = Convert.ToInt32(Console.ReadLine());
c = Convert.ToInt32(Console.ReadLine());

if ((a == b) && (b == c))
{
    int prom = (a + b + c) / 3;
    Console.WriteLine("El promedio de los numeros es de: {0}", prom);
}
if (a % 2 == 0)
{
    if (b % 2 == 0)
    {
        if (c % 2 == 0)
        {
            Console.WriteLine("La suma de los numeros pares es de: {0}", a + b + c);
        }
    }
}
if (a % 2 == 0)
{
    if ((b % 2 == 0) && (c % 2 != 0))
    {
        Console.WriteLine("La suma de los numeros pares es de: {0}", a + b);
    }
}
if (a % 2 == 0)
{
    if ((c % 2 == 0) && (b % 2 != 0))
    {
        Console.WriteLine("La suma de los numeros pares es de: {0}", a + c);
    }
}
if (b % 2 == 0)
{
    if ((c % 2 == 0) && (a % 2 != 0))
    {
        Console.WriteLine("La suma de los numeros pares es de: {0}", c + b);
    }
}
if (a % 2 != 0)
{
    if ((b % 2 != 0) && (c % 2 == 0))
    {
        Console.WriteLine("La suma de los numeros impares es de: {0}", a + b);
    }
}
if (a % 2 != 0)
{
    if ((c % 2 != 0) && (b % 2 == 0))
    {
        Console.WriteLine("La suma de los numeros impares es de: {0}", a + c);
    }
}
if (b % 2 != 0)
{
    if ((c % 2 != 0) && (a % 2 == 0))
    {
        Console.WriteLine("La suma de los numeros impares es de: {0}", c + b);
    }
}
if ((a > b) && (b > c))
{
    Console.WriteLine("El numero mas grande ingresado es: {0}", a);
}
else if ((a < b) && (b < c))
{
    Console.WriteLine("El numero mas pequeño ingresado es: {0}", a);
}
if ((b > a) && (b > c))
{
    Console.WriteLine("El numero mas grande ingresado es: {0}", b);
}
else if ((b < a) && (b < c))
{
    Console.WriteLine("El numero mas pequeño ingresado es: {0}", b);
}
if ((c > a) && (c > b))
{
    Console.WriteLine("El numero mas grande ingresado es: {0}", c);
}
else if ((c < a) && (c < b))
{
    Console.WriteLine("El numero mas pequeño ingresado es: {0}", c);
}