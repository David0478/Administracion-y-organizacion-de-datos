﻿// See https://aka.ms/new-console-template for more information
/*
 */
namespace programaMetodo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a;
            Console.WriteLine("Ingresa un numero:");
            a = Convert.ToInt32(Console.ReadLine());
            leer(a); //mandamos el valor o la variable

        }

        static void leer(int a) //aqui la recibe, es como un def
        {
            Console.WriteLine("el cuadrado de {1} es de: {0}", a *a,a);
        }

    }

}
