﻿// See https://aka.ms/new-console-template for more information
/*
 *hacer un programa que lea nombre,sexo y edad de 3 personas. El programa
 *creara un metodo para validar nombre,edad y sexo, una vez validado los datos
 *se introducira en un archivo
*/

using System.Text;

namespace sexoooo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StreamWriter archivo;
            List<List<string>> datos = new List<List<string>>();
            string nombre, sexo,nomarc="Lista de datos.txt",dato="";
            int edad = 0;
            archivo = File.AppendText(nomarc);


            for (int i = 0; i < 3; i++)
            {
                nombre = Validarnombre();

                edad = Convert.ToInt32(validarnumeros());

                sexo = validarsexo();


                List<string> info = new List<string>();
                info.Add(nombre);
                info.Add(edad.ToString());
                info.Add(sexo);
                datos.Add(info);

                dato = "Los datos ingresados son  " + nombre + " con edad de: " + edad.ToString() + " Y de sexo: " + sexo;
                archivo.WriteLine(dato);

            }
            archivo.Close();


            foreach(var i in datos)
            {
                Console.WriteLine(String.Join(",", i));
            }

        }

        static string Validarnombre()
        {
            int con = 0;
            string re="";
            bool verificador = true;
            byte[] arr = Encoding.ASCII.GetBytes(re);
            while (verificador==true)
            {
                con = 0;
                Console.Write("Ingresa tu nombre: ");
                re = Console.ReadLine();
                arr = Encoding.ASCII.GetBytes(re);
                foreach (byte b in arr)
                {
                if ((char)b >= 97 && (char)b <= 122 /*|| (char)b >= 97 && (char)b <= 122 || (char)b == 32*/)
                {
                    con++;
                }
                }

                if (con == re.Length)
                {
                    verificador = false;
                }
                else
                {
                    Console.WriteLine("Solo letras");
                }
            }
            return re;
        }
            

        static string validarnumeros()
        {
            string ed = "";
            while (true)
            {
                Console.Write("Ingresa tu edad: ");
                ed = Console.ReadLine();

                int edad1 = 0;
                if (Int32.TryParse(ed, out edad1))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Ingresa solo numeros");
                }
            }
            return ed;
           
        }



        static string validarsexo()
        {
            string set = "";
            int con = 0;
            bool verificador = true;
            byte[] arr = Encoding.ASCII.GetBytes(set);

            while (verificador == true)
            {
                con = 0;
                Console.Write("Ingresa tu sexo H o M:  ");
                set = Console.ReadLine();
                arr = Encoding.ASCII.GetBytes(set);

                foreach(byte b in arr)
                {
                    if ((char)b == 72)
                    {
                        con++;
                    }
                    if ((char)b == 77)
                    {
                        con++;
                    }
                }
                if (con == 1)
                {
                    verificador = false;
                }
                else
                {
                    Console.Write("Solo una letra");
                }
            }
            return set;
        }


    }

}