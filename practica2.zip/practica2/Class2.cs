﻿using System;

public class Class1
{
	public Class1()
	{
		Console.WriteLine("Hola mundo");
	}
}
