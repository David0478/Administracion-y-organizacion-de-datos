﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
//un programa que lea 2 numeros que realice la multiplicacion la divicion, la raiz y la potencia
// de esos numeros, en el caso de raiz se saca a los dos numeros.

double a, b, mult, div, raiz1,raiz2, pot1,pot2;
Console.WriteLine("Ingresa dos numeros:  ");
a = Convert.ToDouble(Console.ReadLine());
b = Convert.ToDouble(Console.ReadLine());
mult = a * b;
div = a / b;
raiz1 = Math.Sqrt(a);
raiz2 = Math.Sqrt(b);
pot1 = Math.Pow(a, b);
pot2 = Math.Pow(b, a);
Console.Write("La multiplicacion es de: ");
Console.WriteLine(mult);
Console.Write("La divicion es de: ");
Console.WriteLine(div);
Console.Write("Las raices es de: ");
Console.Write(raiz1);
Console.Write(" y ");
Console.WriteLine(raiz2);
Console.Write("La potencia del primer numero al segundo es de: ");
Console.WriteLine(pot1);
Console.Write("La potencia del segundo numero al primero es de: ");
Console.WriteLine(pot2);
