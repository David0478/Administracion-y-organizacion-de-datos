﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace Segundo
{
    public partial class Productos : Form
    {
        string rutaImagen = null;
        string r;
        string nombrearchivo;
        public Productos()
        {
            InitializeComponent();
            imagen.Image = Image.FromFile("Ascii.jpg");
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string ruta = @"imagenes";
            string rutalocal = @"./imagenes";
            Random random= new Random();
            int r1 = random.Next(1, 1000);
            int r2 = random.Next(1, 10000);
            if (Directory.Exists(ruta))
            {
                string[] listaC = Directory.GetDirectories(rutalocal);
                nombrearchivo = listaC[0] + "img" + r1+ r2+ ".jpg";
                System.IO.File.Copy(r, nombrearchivo, true);
                if (nombrearchivo != null
                && !txtNombre.Text.Equals("")
                && !txtPrecio.Text.Equals(""))
                {
                    StreamWriter usuario = File.AppendText("productos.txt");
                    usuario.WriteLine(txtNombre.Text + "#" + txtPrecio.Text + "#" + nombrearchivo);
                    usuario.Close();
                    MessageBox.Show("El producto se guardo conrrectamente");

                }
            }
            else { 
                 Directory.CreateDirectory(ruta);
                Directory.CreateDirectory(ruta + rutalocal);
                string[] listaC = Directory.GetDirectories(rutalocal);
                nombrearchivo = listaC[0] + "img" + r1 + r2 + ".jpg";
                System.IO.File.Copy(r,nombrearchivo , true);
                if (nombrearchivo != null
                && !txtNombre.Text.Equals("")
                && !txtPrecio.Text.Equals(""))
                {
                    StreamWriter usuario = File.AppendText("productos.txt");
                    usuario.WriteLine(txtNombre.Text + "#" + txtPrecio.Text + "#" + nombrearchivo);
                    usuario.Close();
                    MessageBox.Show("El producto se guardo conrrectamente");

                }



            }

           
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
         
            OpenFileDialog openFileDialog= new OpenFileDialog();
            openFileDialog.Filter="JPG(*.jpg)|*.jpeg|PNG(*.PNG)|*.png";
            if (openFileDialog.ShowDialog() == DialogResult.OK) { 
               r = openFileDialog.FileName;
                imagen.Image = Image.FromFile(r);
            }
        }
    }
}
