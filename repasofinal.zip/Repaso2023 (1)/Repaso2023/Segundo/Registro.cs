﻿using Repaso2023;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Segundo
{
    public partial class Registro : Form
    {
        public int cmi = 0, cmy = 0, cnum = 0, csim = 0, cc = 0, cr = 0;

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            if (txtPassword.Text == txtConfirmarPassword.Text)
            {
                //btnGuardar.Enabled = true;

                string nu, np;
                nu = txtUsuario.Text;
                np = txtPassword.Text;

                if (File.Exists("usuarios.txt")) {

                    StreamWriter usuario = File.AppendText("usuarios.txt");
                    usuario.Write(nu + "#" + np);
                    usuario.Close();
                    MessageBox.Show("El usuario se guardo conrrectamente");

                }
                else {
                    MessageBox.Show("El archivo no existe");
                }
            }
            else
            {
                MessageBox.Show("Faltan datos");
                //btnGuardar.Enabled = false;
            }
       
        
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtConfirmarPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 97 && e.KeyChar <= 122) ||
               (e.KeyChar >= 65 && e.KeyChar <= 90) ||
               (e.KeyChar >= 47 && e.KeyChar < 58) ||
               (e.KeyChar == 95) || (e.KeyChar == 45) || (e.KeyChar == 08))
            {
               
                
            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Caracter Incorrecto");
            }
        }

        public bool vu = false, vp = false;
        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            validar valiLogin = new validar();
            if ((e.KeyChar >= 97 && e.KeyChar <= 122) ||
                (e.KeyChar >= 65 && e.KeyChar <= 90) ||
                (e.KeyChar >= 47 && e.KeyChar < 58) ||
                (e.KeyChar == 95) || (e.KeyChar == 45) || (e.KeyChar == 08))
            {

                cc++;
                //MessageBox.Show(Convert.ToString(cc));
                //MessageBox.Show(Convert.ToString(cr));
                if (cc == cr)
                {
                    valiLogin.revisarLogin(txtPassword.Text);
                }
                if (e.KeyChar == 08)
                {
                    cr = cc - 1;
                    cc -= 2;
                    //MessageBox.Show(Convert.ToString(cc));

                    // MessageBox.Show(txtPassword.Text);
                    //string l = letra.Substring(letra.Length-1);

                }
                if (e.KeyChar >= 97 && e.KeyChar <= 122)
                {
                    lblam.ForeColor = Color.Green;
                    cmi++;
                }
                else if (e.KeyChar >= 65 && e.KeyChar <= 90)
                {
                    cmy++;
                    lblA.ForeColor = Color.Green;
                }
                else if (e.KeyChar >= 47 && e.KeyChar < 58)
                {
                    lbl1.ForeColor = Color.Green;
                    cnum++;
                }
                else if ((e.KeyChar == 95) || (e.KeyChar == 45))
                {
                    lblguion.ForeColor = Color.Green;
                    csim++;

                }
                // MessageBox.Show(Convert.ToString(cmi) + " " + Convert.ToString(cmy) + " " + Convert.ToString(cnum) +
                //   Convert.ToString(cc));
                if (cmi > 0 && cmy > 0 && cnum > 0 && csim > 0 && cc == 8)
                {
                    lblValidar.Text = "Correcto";
                    lblMayor8.ForeColor = Color.Green;
                    vp = true;
                    if (vp == true && vu == true)
                    {
                        btnGuardar.Enabled = true;
                    }
                    else
                    {
                        btnGuardar.Enabled = false;
                    }
                }
                else
                {
                    btnGuardar.Enabled = false;
                    vp = false;
                    lblValidar.Text = "";
                    if (csim == 0)
                    {
                        lblguion.ForeColor = Color.Red;
                    }
                    if (cnum == 0)
                    {
                        lbl1.ForeColor = Color.Red;
                    }
                    if (cmy == 0)
                    {
                        lblA.ForeColor = Color.Red;
                    }
                    if (cmi == 0)
                    {
                        lblam.ForeColor = Color.Red;
                    }
                }

            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Caracter Incorrecto");
            }

        }
        


        public Registro()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtUsuario_KeyPress(object sender, KeyPressEventArgs e)
        {
            //MessageBox.Show(Convert.ToString(e.KeyChar));
            if ((e.KeyChar >= 97 && e.KeyChar <= 122) ||
                (e.KeyChar >= 65 && e.KeyChar <= 90) ||
                (e.KeyChar >= 47 && e.KeyChar < 58) || (e.KeyChar == 08))
            {
                vu = true;
                if (vp == true && vu == true)
                {
                    btnGuardar.Enabled = true;
                }
                else
                {
                    btnGuardar.Enabled = false;
                }
            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Caracter Incorrecto");
            }
        }
    }
}
