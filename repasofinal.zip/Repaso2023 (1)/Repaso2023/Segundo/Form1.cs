using Repaso2023;
using System.Text;

namespace Segundo
{
    public partial class Form1 : Form
    {
        public int cmi = 0, cmy = 0, cnum = 0, csim = 0, cc = 0, cr=0;
        public bool vu = false, vp=false;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            string u="", p="";
            string cad = "", us, pa;
            bool ban = false;
            u = txtUsuario.Text;
            p = txtPassword.Text;

            if (!File.Exists("usuarios.txt")) {
                StreamWriter archivo = File.AppendText("usuarios.txt");
                archivo.WriteLine("admin#Admin_12");
                archivo.Close();
            }
           
            StreamReader archivo2 = File.OpenText("usuarios.txt");
            do{
                cad = archivo2.ReadLine();
                if (!String.IsNullOrEmpty(cad)) { 
                   int pos = cad.IndexOf('#');
                    us = cad.Substring(0, pos);
                    pa = cad.Substring(pos + 1);
                    if (u.Equals(us) && p.Equals(pa))
                    {
                        ban = true;
                      
                    }
                }
            }while (cad!=null) ;



            if (ban == false)
            {
                MessageBox.Show("El usuario no existe");
            }
            else {

                archivo2.Close();
                Principal pr = new Principal();
                pr.mnuSusuario.Text = u;
                if (!u.Equals("admin")) { 
                     pr.mnuAAgregarU.Enabled = false;
                }
                this.Hide();
                pr.ShowDialog();
            }
          
        }


       

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {

            validar valiLogin = new validar();
            if ((e.KeyChar >= 97 && e.KeyChar <= 122) ||
                (e.KeyChar >= 65 && e.KeyChar <= 90) ||
                (e.KeyChar >= 47 && e.KeyChar < 58)  || 
                (e.KeyChar==95) || (e.KeyChar==45) || (e.KeyChar == 08))
            {
                
                cc++;
                //MessageBox.Show(Convert.ToString(cc));
                //MessageBox.Show(Convert.ToString(cr));
                if (cc == cr) { 
                    valiLogin.revisarLogin(txtPassword.Text);
                }
                if (e.KeyChar == 08) {
                    cr = cc-1;
                    cc-=2;
                    //MessageBox.Show(Convert.ToString(cc));
                     
                   // MessageBox.Show(txtPassword.Text);
                    //string l = letra.Substring(letra.Length-1);

                }
                if (e.KeyChar >= 97 && e.KeyChar <= 122)
                {
                    lblam.ForeColor = Color.Green;
                    cmi++;
                }
                else if (e.KeyChar >= 65 && e.KeyChar <= 90) {
                    cmy++;
                    lblA.ForeColor = Color.Green;
                }
                else if (e.KeyChar >= 47 && e.KeyChar < 58)
                {
                    lbl1.ForeColor = Color.Green;
                    cnum++;
                }
                else if ((e.KeyChar == 95) || (e.KeyChar == 45))
                {
                    lblguion.ForeColor = Color.Green;
                    csim++;
                    
                }
               // MessageBox.Show(Convert.ToString(cmi) + " " + Convert.ToString(cmy) + " " + Convert.ToString(cnum) +
               //   Convert.ToString(cc));
                if (cmi > 0 && cmy > 0 && cnum > 0 && csim > 0 && cc == 8)
                {
                    lblValidar.Text = "Correcto";
                    lblMayor8.ForeColor = Color.Green;
                    vp = true;
                    if (vp == true && vu == true)
                    {
                        btnAceptar.Enabled = true;
                    }
                    else
                    {
                        btnAceptar.Enabled = false;
                    }
                }
                else {
                    btnAceptar.Enabled = false;
                    vp = false;
                    lblValidar.Text = "";
                    if (csim == 0) {
                        lblguion.ForeColor = Color.Red;
                    }
                    if (cnum == 0) {
                        lbl1.ForeColor = Color.Red;
                    }
                    if (cmy == 0) {
                        lblA.ForeColor = Color.Red;
                    }
                    if (cmi == 0) {
                        lblam.ForeColor = Color.Red;
                    }
                }

            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Caracter Incorrecto");
            }
        }

        private void txtUsuario_KeyPress(object sender, KeyPressEventArgs e)
        {
            //MessageBox.Show(Convert.ToString(e.KeyChar));
            if ((e.KeyChar >= 97 && e.KeyChar <= 122) ||
                (e.KeyChar >= 65 && e.KeyChar <= 90) ||
                (e.KeyChar >= 47 && e.KeyChar < 58) ||(e.KeyChar==08))
            {
                vu = true;
                if (vp == true && vu == true)
                {
                    btnAceptar.Enabled = true;
                }
                else {
                    btnAceptar.Enabled = false;
                }
            }
            else { 
              e.Handled= true;
                MessageBox.Show("Caracter Incorrecto");
            } 
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}