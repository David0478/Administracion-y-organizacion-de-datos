﻿using Segundo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repaso2023
{
    internal class validar
    {
        public void revisarLogin(string cad)
        {
            Form1 f = new Form1();
            int cn2 = 0, clm2 = 0, cmla2 = 0, cs2 = 0;
            byte[] arr = Encoding.ASCII.GetBytes(cad);
            foreach (byte e in arr)
            {

                if ((char)e >= 48 && (char)e <= 57)
                {
                    cn2++;
                }

                if ((char)e >= 97 && (char)e <= 122)
                {
                    clm2++;
                }

                if ((char)e >= 65 && (char)e <= 90)
                {
                    cmla2++;
                }
                if ((char)e == 95 || (char)e == 45)
                {
                    cs2++;
                }
            }

            if (clm2 == 0)
            {
                if (f.cmi > 0)
                {
                    f.cmi--;
                }
                if (clm2 == 0)
                {
                    f.lblam.ForeColor = Color.Red;
                }
                //MessageBox.Show("Falan una minuscula");
            }

            if (cmla2 == 0)
            {
                if (f.cmy > 0)
                {
                    f.cmy--;
                }
                if (f.cmy == 0)
                {
                    f.lblA.ForeColor = Color.Red;
                }
                //MessageBox.Show("Falan una mayuscula");
            }

            if (cs2 == 0)
            {
                if (f.csim > 0)
                {
                    f.csim--;

                }
                if (f.csim == 0)
                {
                    f.lblguion.ForeColor = Color.Red;
                }
                //MessageBox.Show("Falan un simbolo");
            }

            if (cn2 == 0)
            {
                if (f.cnum > 0)
                {
                    f.cnum--;
                }
                MessageBox.Show("Numeros " + Convert.ToString(f.cnum));
                if (f.cnum == 0)
                {
                    f.lbl1.ForeColor = Color.Red;
                }
                //MessageBox.Show("Falan un numero");
            }
        }
    }
}
