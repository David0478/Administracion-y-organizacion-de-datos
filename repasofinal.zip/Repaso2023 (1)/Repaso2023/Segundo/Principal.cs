﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace Segundo
{
    public partial class Principal : Form
    {
        public string usuario;
        public Principal()
        {
            InitializeComponent();
            cargarGrid();
            cargarusuarios();

        }

        private void cargarGrid() {
            string s;
            if (File.Exists("productos.txt")) {
                StreamReader leer = File.OpenText("productos.txt");
                do
                {
                     s = leer.ReadLine();
                    if (String.IsNullOrEmpty(s))
                    {
                        MessageBox.Show("El arhino esta vacio");
                    }
                    else
                    {

                        int pos = s.IndexOf('#');
                        string s2 = s.Substring(pos + 1);
                        string ss = s.Substring(0, pos); //nombre producto
                        int pos1 = s2.IndexOf('#');
                        string s3 = s2.Substring(0, pos1);//precio
                        string s4 = s2.Substring(pos1 + 1);//ruta de la imagen
                        string s5 = "";
                        byte[] arr = Encoding.ASCII.GetBytes(s4);
                        foreach (byte i in arr)
                        {
                            if (i != 92)
                            {
                                s5 += Convert.ToChar(i).ToString();
                            }
                            else
                            {
                                s5 += "/";
                            }
                        }
                        MessageBox.Show(s5);

                        dataGridProductos.Rows.Add(
                               ss,
                               s3,
                               Image.FromFile(s5));
                    }
                } while (s != null);

                leer.Close();

            }
        
        }

        private void Principal_Load(object sender, EventArgs e)
        {
            lblUsuario.Text = usuario;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void mnuSCerrar_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.txtUsuario.Text = "";
            form1.txtPassword.Text = "";
            form1.ShowDialog();
            
        }

        private void mnuAAgregarU_Click(object sender, EventArgs e)
        {
            Registro reg = new Registro();
            reg.ShowDialog();
        }

        private void mnuASalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void mnuPAgregar_Click(object sender, EventArgs e)
        {
            Productos productos = new Productos();
            productos.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            

        }

        private void cargarusuarios()
        {
            string s;
            if (File.Exists("usuarios.txt"))
            {
                StreamReader leer = File.OpenText("usuarios.txt");
                do
                {
                    s = leer.ReadLine();
                    if (String.IsNullOrEmpty(s))
                    {
                        MessageBox.Show("El arhino esta vacio");
                    }
                    else
                    {

                        int pos = s.IndexOf('#');
                        string us = s.Substring(0, pos);
                        string pa = s.Substring(pos + 1);


                        dataGridUsuarios.Rows.Add(
                               us,
                               pa);
                    }
                } while (s != null);

                leer.Close();

            }
        }
    }
}
