﻿// See https://aka.ms/new-console-template for more information
/*
//for
for (int x = 0; x < 10; x++)
{
    Console.WriteLine(x);
}

for (int i = 10; i > 0; i--)
{
    Console.WriteLine(i);
}
int x = 0;
Console.WriteLine(x++);
Console.WriteLine(++x);
*/

/*

String[] a = { "Hola", "Adios" };
foreach (String i  in a)
{
    Console.WriteLine(i);
}

//while
int w = 0;
while (true)
{
    w++;
    if (w > 10)
    {
        break;
    }
    else
    {
        Console.WriteLine(w);
    }

}
*/
//DoWhile 
/*
do
{




} while (true);
*/
//hacer un programa que lea un numero, si el numero no es par, se volvera a pedir, de lo contrario
//mostrara todos los numeros que hay entre 0 y el, el numero no debe de ser negativo.


bool verificador = true;

while (verificador == true)
{
    int a;
    Console.WriteLine("Ingresa un numero");

    a = Convert.ToInt32(Console.ReadLine());

    if (a >= 0)
    {
        if (a % 2 == 0)
        {
            Console.WriteLine("Los numeros anteriores al ingresados son");
            for (int i = 0; i < a; i++)
            {
                Console.WriteLine(i);
            }
            verificador = false;

        }
        else
        {
            Console.WriteLine("Solo numeros pares");
        }

    }
    else
    {
        Console.WriteLine("Solo numeros positivos");
    }



}